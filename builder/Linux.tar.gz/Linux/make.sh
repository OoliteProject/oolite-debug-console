#!/bin/bash


q(){ echo "Error at: $*" >&2 ; exit 5 ; } # exit function

#Do apt installs. Only needed on first run.
#To not do this, simply call this script with one argument: nocheck
[ "x$1" != "xnocheck" ] && {
    step="package install"
    sudo apt install python3-tk python3-pip python3-venv binutils || q "$step"
}

basedir="$(dirname $(realpath $0))"
[ -d "$basedir" ] || q "Insane basedir '$basedir'"
cd "$basedir" || q "Can't cd to $basedir"
ver=$(cat ../../version)
[ "x$ver" = "x" ] && q "version not found. version file empty or absent"
builddir="$basedir/build" # this can be deleted to retry a build
basename=OoliteDebugConsole # gets used a lot
inscript=DebugConsole.py # the name of the script we'll be 'compiling'
zipfile="$basedir/${basename}-latest.zip"
localtarball="$basedir/${basename}$ver-linux-installable.tar.gz"
#to use different tarball name. Not sanitised.
[ "x$1" != "x"] && [ "x$1" != "xnocheck"] && \
    localtarball="$1"
#this overrides the filename for build on github.
[ "x$1" = "xgithub"] && localtarball="$basedir/Linux-installable.tar"
venv="$builddir/pyinstaller"
dist="${basename}$ver" # the directory exracted from zip
relpath="../../../"

step="setting up venv and building tools"
python3 -m venv "$venv" &&
source "$venv"/bin/activate &&
pip install twisted &&
pip install pyinstaller || q "$step"

step="making executable"
cd "$builddir" || q "Can't cd to builddir $builddir"
pyinstaller --name "$basename" --onefile "${relpath}$inscript" \
 --add-binary "${relpath}oojsc.xbm:." --add-binary "${relpath}OoJSC.ico:." \
 --add-binary "${relpath}OoJSC256x256.png:." &&
cd "$basedir" && mv "$builddir/dist/$basename" . &&
tar -C "$basedir/install-tree" --numeric-owner --dereference \
 -cpzf "$localtarball" . || q "$failed to build local-install tarball"

echo "
Finished. The executable is at '$basedir/$basename'.

An install tarball is at '$localtarball'.
To install it as a user-local install, extract it in \$HOME/.local

example:-
tar -xpzf '$localtarball' -C \$HOME/.local

If you have root access, you can install it system local like this:
sudo tar -xpzf '$localtarball' -C /usr/local

If it's installed user-local, that install will (for that user) take priority over system versions.

" || q "$step"

#end
